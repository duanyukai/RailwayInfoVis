import React from 'react';
import './style.scss';

const Footer = () => (
  <footer>
    <section>清华大学 2019</section>
  </footer>
);

export default Footer;
